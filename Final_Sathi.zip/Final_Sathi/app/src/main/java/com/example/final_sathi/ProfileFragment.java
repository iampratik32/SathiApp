package com.example.final_sathi;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import static android.app.Activity.RESULT_OK;

public class ProfileFragment extends Fragment {

    public static final int REQUEST_CODE = 10001;

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_profile, container, false);



        final ImageButton settingsButton = view.findViewById(R.id.profileFragment_settingsButton);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent settingsIntent = new Intent(getActivity(),SettingsActivity.class);
                startActivity(settingsIntent);
            }
        });

        ImageView profilePhoto = view.findViewById(R.id.user_profilePhoto);

        ImageButton cameraButton = view.findViewById(R.id.profileFragment_addPhotosButton);
        cameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DialogHandleMedia dialog = new DialogHandleMedia();
                dialog.show(getFragmentManager(),"Dialog");
            }
        });

        TextView nameOfUser = view.findViewById(R.id.profileFragment_nameOfUser);
        TextView bioOfUser = view.findViewById(R.id.profileFragment_bioOfUser);
        bioOfUser.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD);
        SathiUser currentSathiUser = SathiUserHolder.getSathiUser();
        nameOfUser.setText(currentSathiUser.getName());
        bioOfUser.setText(currentSathiUser.getBio());


        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE){
            if(requestCode == RESULT_OK){
                DialogHandleMedia dialog = new DialogHandleMedia();
                dialog.show(getFragmentManager(),"Dialog");
            }
            else {
                System.out.println("in here qqqqqqq");
            }
        }
        else {
            System.out.println("In here qweqweqweqwewqeqweqwe");
        }
    }
}
