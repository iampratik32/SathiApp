package com.example.final_sathi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.app.DownloadManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.internal.Storage;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import static androidx.appcompat.app.AlertController.*;

public class ChooseMediaType extends AppCompatActivity {

    private StorageReference mStorageRef;
    RecycleListView recycleListView;
    private DatabaseReference databaseReference;
    ArrayList<Uri> fileList = new ArrayList<Uri>();
    Integer REQUEST_CAMERA =1, SELECT_FILE=0;

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_media_type);

        recycleListView = findViewById(R.id.uploadList);

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.settingsColor));

        Button backButton = findViewById(R.id.goBackButton_chooseMedia);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        LinearLayout chooseFromCamera = findViewById(R.id.chooseFromCamera_linearLayout);
        LinearLayout chooseFromGallery = findViewById(R.id.chooseFromGallery_linearLayout);

        chooseFromCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        chooseFromGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.READ_EXTERNAL_STORAGE)!= PackageManager.PERMISSION_GRANTED){
                    ActivityCompat.requestPermissions(ChooseMediaType.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1000);
                    return;
                }
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
                intent.setType("image/*");
                startActivityForResult(intent.createChooser(intent,"Select File"),SELECT_FILE);
            }
        });

    }
    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public  void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        ImageView camera = findViewById(R.id.choose_media_camera);
        ImageView gallery = findViewById(R.id.choose_media_gallery);
        final LinkedList<Uri> uriList = new LinkedList<>();
        final LinkedList<String> fileLocation = new LinkedList<>();

        if(resultCode== Activity.RESULT_OK) {
            if(requestCode== REQUEST_CAMERA){
                Bundle bundle = data.getExtras();
                final Bitmap bitmap = (Bitmap) bundle.get("data");
                camera.setImageBitmap(bitmap);
            }
            else if(requestCode==SELECT_FILE){
                ClipData clipData = data.getClipData();
                if(clipData!=null){
                    int count = clipData.getItemCount();
                    int i=0;
                    while (i<count){
                        Uri file = clipData.getItemAt(i).getUri();
                        fileList.add(file);
                        i++;
                    }
                    for(int j=0;j<fileList.size();j++){
                        Uri images = fileList.get(j);

                        try{
                            InputStream is = getContentResolver().openInputStream(images);
                            Bitmap bitmap = BitmapFactory.decodeStream(is);
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG,20,baos);
                            byte[] byteData = baos.toByteArray();
                            mStorageRef = FirebaseStorage.getInstance().getReference(SathiUserHolder.getSathiUser().getUserId());
                            StorageReference finalFileName = mStorageRef.child("File"+images.getLastPathSegment());
                            finalFileName.putBytes(byteData).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    DatabaseReference finalDatabaseReference = FirebaseDatabase.getInstance().getReference().child("Users").child(SathiUserHolder.getSathiUser().getGender()).child(SathiUserHolder.getSathiUser().getUserId()).child("Images");
                                    final HashMap<String,String> hashMap = new HashMap<>();
                                    hashMap.put("Link",String.valueOf(taskSnapshot.getUploadSessionUri()));
                                    finalDatabaseReference.push().setValue(hashMap);
                                    fileList.clear();
                                }
                            });
                        }
                        catch (FileNotFoundException e){
                            e.printStackTrace();
                        }
                    }
                }
                else{

                }
                setResult(Activity.RESULT_OK);
                finish();
            }
        }

    }
    public void UploadFiles(){

    }
}
