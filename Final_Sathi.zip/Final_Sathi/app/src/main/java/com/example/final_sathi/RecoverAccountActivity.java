package com.example.final_sathi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class RecoverAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recover_account);

        Button recoverButton = findViewById(R.id.button_recoverEmail);
        final TextInputEditText recoverEmail = findViewById(R.id.emailRecovery);

        recoverButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String takenEmail = recoverEmail.getText().toString().trim();
                if(takenEmail.isEmpty()){
                    recoverEmail.requestFocus();
                    recoverEmail.setError("Enter email.");
                }
                else if(!EmailValidator.validateEmail(takenEmail)){
                    recoverEmail.setError("Enter valid Email Address");
                    recoverEmail.requestFocus();
                }
                else {
                    FirebaseAuth.getInstance().sendPasswordResetEmail(takenEmail).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(getApplicationContext(),"Email Sent",Toast.LENGTH_LONG).show();
                            }
                            else {
                                Toast.makeText(getApplicationContext(),"Failed.",Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        });

        Button backButton = findViewById(R.id.button_goBackRecoverEmail);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}
