package com.example.final_sathi;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.os.CountDownTimer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.lorentzos.flingswipe.SwipeFlingAdapterView;

import java.util.ArrayList;
import java.util.List;

import static com.facebook.FacebookSdk.getApplicationContext;


public class MainFragment extends Fragment {

    private PotentialMatchesInfo potentialMatchesInfo[];
    private PotentialMatchesArrayAdapter arrayAdapter;
    ListView listView;
    List<PotentialMatchesInfo> rowItems;
    private int i;
    PleaseWaitDialog dialog;
    CountDownTimer countDownTimer;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_main, container, false);
        dialog = new PleaseWaitDialog();

        rowItems = new ArrayList<PotentialMatchesInfo>();
        showPotentialMatches();

        arrayAdapter = new PotentialMatchesArrayAdapter(getContext(), R.layout.swipe_items, rowItems );
        SwipeFlingAdapterView fillingContainer = view.findViewById(R.id.swipeFrame);
        fillingContainer.setAdapter(arrayAdapter);
        fillingContainer.setFlingListener(new SwipeFlingAdapterView.onFlingListener() {
            @Override
            public void removeFirstObjectInAdapter() {
                rowItems.remove(0);
                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onLeftCardExit(Object o) {
                Toast.makeText(getContext(),"Left",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onRightCardExit(Object o) {
                Toast.makeText(getContext(),"Right",Toast.LENGTH_LONG).show();
            }

            @Override
            public void onAdapterAboutToEmpty(int i) {
            }

            @Override
            public void onScroll(float v) {

            }
        });

        fillingContainer.setOnItemClickListener(new SwipeFlingAdapterView.OnItemClickListener() {
            @Override
            public void onItemClicked(int i, Object o) {
                Toast.makeText(getContext(),"Click",Toast.LENGTH_LONG).show();

            }
        });

        if(SathiUserHolder.getSathiUser()==null){
            dialog.show(getFragmentManager(),"Dialog");
            countDownTimer = new CountDownTimer(5000,1000) {
                @Override
                public void onTick(long millisUntilFinished) {

                }

                @Override
                public void onFinish() {
                    dialog.dismiss();
                    showPotentialMatches();
                }
            }.start();
        }

        return view;

    }
    public void showPotentialMatches(){
        if(SathiUserHolder.getSathiUser()!=null){
            SathiUser currentUser = SathiUserHolder.getSathiUser();
            final String userId = currentUser.getUserId();
            final String userPreference = currentUser.getPreference();
            final String userGender = currentUser.getGender();
            if(userPreference.equals("Both")){
                DatabaseReference manDatabase =  FirebaseDatabase.getInstance().getReference().child("Users").child("Man");
                DatabaseReference womanDatabase =  FirebaseDatabase.getInstance().getReference().child("Users").child("Woman");
                manDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            for(DataSnapshot postSnapshot:dataSnapshot.getChildren()){
                                if(!userId.equals(postSnapshot.getKey())){
                                    if(postSnapshot.child("Preference").getValue().toString().equals(userGender) || postSnapshot.child("Preference").getValue().toString().equals("Both")){
                                        PotentialMatchesInfo potentialMatchesInfo = new PotentialMatchesInfo(postSnapshot.getKey(),postSnapshot.child("Name").getValue().toString()
                                                ,postSnapshot.child("Bio").getValue().toString(),postSnapshot.child("Age").getValue().toString(),postSnapshot.child("ShowAge").getValue().toString());
                                        rowItems.add(potentialMatchesInfo);
                                        arrayAdapter.notifyDataSetChanged();
                                    }
                                }
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

                womanDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            for(DataSnapshot postSnapshot:dataSnapshot.getChildren()){
                                if(!userId.equals(postSnapshot.getKey())){
                                    if(postSnapshot.child("Preference").getValue().toString().equals(userGender) || postSnapshot.child("Preference").getValue().toString().equals("Both")){
                                        PotentialMatchesInfo potentialMatchesInfo = new PotentialMatchesInfo(postSnapshot.getKey(),postSnapshot.child("Name").getValue().toString()
                                                ,postSnapshot.child("Bio").getValue().toString(),postSnapshot.child("Age").getValue().toString(),postSnapshot.child("ShowAge").getValue().toString());
                                        rowItems.add(potentialMatchesInfo);
                                        arrayAdapter.notifyDataSetChanged();
                                    }
                                }
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

            else{

                DatabaseReference preferredDatabase =  FirebaseDatabase.getInstance().getReference().child("Users").child(userPreference);
                preferredDatabase.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot.exists()){
                            for (DataSnapshot postSnapshot: dataSnapshot.getChildren()){
                                if(!userId.equals(postSnapshot.getKey())){
                                    if(userGender.equals(userPreference)){
                                        if(postSnapshot.child("Preference").getValue().toString().equals(userPreference) || postSnapshot.child("Preference").getValue().toString().equals("Both")){
                                            PotentialMatchesInfo potentialMatchesInfo = new PotentialMatchesInfo(postSnapshot.getKey(),postSnapshot.child("Name").getValue().toString()
                                                    ,postSnapshot.child("Bio").getValue().toString(),postSnapshot.child("Age").getValue().toString(),postSnapshot.child("ShowAge").getValue().toString());
                                            rowItems.add(potentialMatchesInfo);
                                            arrayAdapter.notifyDataSetChanged();
                                        }
                                    }
                                    else{
                                        if(postSnapshot.child("Preference").getValue().toString().equals(userGender) || postSnapshot.child("Preference").getValue().toString().equals("Both")){
                                            PotentialMatchesInfo potentialMatchesInfo = new PotentialMatchesInfo(postSnapshot.getKey(),postSnapshot.child("Name").getValue().toString()
                                                    ,postSnapshot.child("Bio").getValue().toString(),postSnapshot.child("Age").getValue().toString(),postSnapshot.child("ShowAge").getValue().toString());
                                            rowItems.add(potentialMatchesInfo);
                                            arrayAdapter.notifyDataSetChanged();
                                        }
                                    }
                                }
                            }
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        }
    }
}
