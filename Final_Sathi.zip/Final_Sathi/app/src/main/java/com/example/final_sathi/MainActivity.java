package com.example.final_sathi;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SathiUser sathiUser;
    FirebaseAuth firebaseAuth;


    private boolean backPressedOnce = false;
    @Override
    public void onBackPressed() {
        if (backPressedOnce) {
            super.onBackPressed();
            return;
        }
        this.backPressedOnce = true;
        Toast.makeText(this, "Press back again to quit.", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                backPressedOnce=false;
            }
        }, 2000);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final String userId = FirebaseAuth.getInstance().getUid();
        DatabaseReference manDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Man").child(userId);
        DatabaseReference womanDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Woman").child(userId);
        manDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    sathiUser = new SathiUser(userId,dataSnapshot.child("Name").getValue().toString(),"Man",Integer.parseInt(dataSnapshot.child("Age")
                            .getValue().toString()),dataSnapshot.child("Bio").getValue().toString(),dataSnapshot.child("Distance").getValue()
                            .toString(),dataSnapshot.child("Email").getValue().toString(),dataSnapshot.child("Preference").getValue().toString()
                            ,dataSnapshot.child("ShowAge").getValue().toString());
                    SathiUserHolder.setSathiUser(sathiUser);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        womanDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    sathiUser = new SathiUser(userId,dataSnapshot.child("Name").getValue().toString(),"Woman",Integer.parseInt(dataSnapshot.child("Age")
                            .getValue().toString()),dataSnapshot.child("Bio").getValue().toString(),dataSnapshot.child("Distance").getValue()
                            .toString(),dataSnapshot.child("Email").getValue().toString(),dataSnapshot.child("Preference").getValue().toString()
                            ,dataSnapshot.child("ShowAge").getValue().toString());
                    SathiUserHolder.setSathiUser(sathiUser);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.colorForMainGradientBack));

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigator);
        bottomNavigationView.setOnNavigationItemSelectedListener(navigationListener);
        bottomNavigationView.setSelectedItemId(R.id.sathiButton);



    }
    private BottomNavigationView.OnNavigationItemSelectedListener navigationListener = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
            Fragment selectedFragment = null;
            switch (menuItem.getItemId()){
                case R.id.profileButton:
                    selectedFragment = new ProfileFragment();
                    break;


                case R.id.sathiButton:
                    selectedFragment = new MainFragment();
                    break;

                case R.id.chatButton:
                    selectedFragment = new ChatFragment();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.mainActivityFrameLayout,selectedFragment).commit();
            return true;
        }
    };
}
