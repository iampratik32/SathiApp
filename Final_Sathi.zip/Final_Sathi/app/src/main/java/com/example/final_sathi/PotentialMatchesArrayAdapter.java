package com.example.final_sathi;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class PotentialMatchesArrayAdapter extends ArrayAdapter<PotentialMatchesInfo> {

    Context context;

    public PotentialMatchesArrayAdapter(Context context, int resourceId, List<PotentialMatchesInfo> potentialMatchesInfoList){
        super(context,resourceId,potentialMatchesInfoList);
    }

    public View getView(int position, View convertView, ViewGroup parent){
        PotentialMatchesInfo potentialMatchesInfo = getItem(position);

        if(convertView==null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.swipe_items,parent, false);
        }

        TextView userName = convertView.findViewById(R.id.swipe_item_userNameText);
        ImageView userImage = convertView.findViewById(R.id.swipe_item_userImage);
        TextView userBio = convertView.findViewById(R.id.swipe_item_userBioText);
        TextView userAge = convertView.findViewById(R.id.swipe_item_userAgeText);

        userName.setText(potentialMatchesInfo.getUserName());
        userImage.setImageResource(R.drawable.main_application_gradient_background);
        userBio.setText(potentialMatchesInfo.getBio());
        if(potentialMatchesInfo.getShowAge().equals("true")){
            userAge.setText(potentialMatchesInfo.getAge());
        }

        return convertView;
    }
}
