package com.example.final_sathi;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class SettingsActivity extends AppCompatActivity {
    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        auth = FirebaseAuth.getInstance();

        TextView tempSignOut = findViewById(R.id.tempSignout);
        SathiUser currentUser = SathiUserHolder.getSathiUser();
        tempSignOut.setText(currentUser.getName());
        tempSignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                startActivity(new Intent(SettingsActivity.this,LoginActivity.class));
                finish();
            }
        });
    }
}
