package com.example.final_sathi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.arch.core.executor.TaskExecutor;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.net.wifi.hotspot2.pps.Credential;
import android.os.Build;
import android.os.Bundle;

import android.text.Html;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;


public class LoginFromPhoneActivity extends AppCompatActivity {

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_from_phone);

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.secondaryColor));

        TextView yourPhone = findViewById(R.id.loginPhonePage_textPhoneNumber);
        yourPhone.setText(Html.fromHtml(String.format(getString(R.string.phone_number))));

        final TextInputEditText phoneNumber = findViewById(R.id.loginFromPhone);
        phoneNumber.requestFocus();
        if(phoneNumber.hasFocus()){
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        }

        Button continueButton  = findViewById(R.id.phoneLogin_buttonContinue);
        continueButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String takenPhoneNumber = phoneNumber.getText().toString().trim();
                if(takenPhoneNumber.isEmpty() || takenPhoneNumber.length()<10){
                    phoneNumber.setError("Enter Valid Phone Number");
                }
                else{
                    String finalPhoneNumber = "+977"+takenPhoneNumber;
                    Intent verifyPhone = new Intent(LoginFromPhoneActivity.this,VerifyPhoneActivity.class);
                    verifyPhone.putExtra("phoneNumber",finalPhoneNumber);
                    startActivity(verifyPhone);
                    finish();
                }

            }
        });

        Button emailButton = findViewById(R.id.phoneLogin_buttonEmailLogin);
        emailButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent newIntent = new Intent(LoginFromPhoneActivity.this,LoginWithEmailActivity.class);
                startActivity(newIntent);
                finish();
            }
        });

    }


}
