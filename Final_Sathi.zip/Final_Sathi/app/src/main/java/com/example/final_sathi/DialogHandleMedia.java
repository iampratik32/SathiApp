package com.example.final_sathi;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.Image;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatDialogFragment;
import androidx.cardview.widget.CardView;

import java.util.List;

import static com.example.final_sathi.ProfileFragment.REQUEST_CODE;

public class DialogHandleMedia extends AppCompatDialogFragment {

    @Override
    public void onResume() {
        super.onResume();
        getDialog().setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialog, int keyCode, KeyEvent event) {
                if(keyCode == KeyEvent.KEYCODE_BACK){
                    dismiss();
                    return true;
                }
                else{
                    return false;
                }
            }
        });
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setCancelable(false);
        LayoutInflater inflater = getActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.dialog_handle_media,null);
        builder.setView(view);

        ImageView closeButton = view.findViewById(R.id.closeButton_handleMedia);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
            }
        });


        Button addPhotos = view.findViewById(R.id.addPhoto_handleMedia);
        CardView firstCardView = view.findViewById(R.id.firstCardView_handleMedia);
        CardView secondCardView = view.findViewById(R.id.secondCardView_handleMedia);
        CardView thirdCardView = view.findViewById(R.id.thirdCardView_handleMedia);
        CardView fourthCardView = view.findViewById(R.id.fourthCardView_handleMedia);
        CardView fifthCardView = view.findViewById(R.id.fifthCardView_handleMedia);
        CardView sixthCardView = view.findViewById(R.id.sixthCardView_handleMedia);
        CardView seventhCardView = view.findViewById(R.id.seventhCardView_handleMedia);
        CardView eighthCardView = view.findViewById(R.id.eighthCardView_handleMedia);
        CardView ninthCardView = view.findViewById(R.id.ninthCardView_handleMedia);

        ImageView firstImage = view.findViewById(R.id.handleMedia_firstPhoto);
        ImageView secondImage = view.findViewById(R.id.handleMedia_secondPhoto);
        ImageView thirdImage = view.findViewById(R.id.handleMedia_thirdPhoto);
        ImageView fourthImage = view.findViewById(R.id.handleMedia_fourthPhoto);
        ImageView fifthImage = view.findViewById(R.id.handleMedia_fifthPhoto);
        ImageView sixthImage = view.findViewById(R.id.handleMedia_sixthPhoto);
        ImageView seventhImage = view.findViewById(R.id.handleMedia_seventhPhoto);
        ImageView eighthImage = view.findViewById(R.id.handleMedia_eighthPhoto);
        ImageView ninthmage = view.findViewById(R.id.handleMedia_ninthPhoto);

        addPhotos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        firstCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        secondCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        thirdCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        fourthCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        fifthCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        sixthCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        seventhCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        eighthCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });
        ninthCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseMedia();
            }
        });

        return builder.create();

    }

    private void chooseMedia(){
        Intent pickMedia = new Intent(getContext(),ChooseMediaType.class);
        startActivityForResult(pickMedia,REQUEST_CODE);
        dismiss();
    }

}
