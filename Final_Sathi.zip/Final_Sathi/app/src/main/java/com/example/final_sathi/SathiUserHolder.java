package com.example.final_sathi;

public class SathiUserHolder {

    private static SathiUser sathiUser = null;

    public static void setSathiUser(SathiUser user){
        sathiUser = user;
    }
    public static SathiUser getSathiUser(){
        return sathiUser;
    }
}
