package com.example.final_sathi;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginWithEmailActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private PleaseWaitDialog pleaseWaitDialog;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_with_email);
        mAuth = FirebaseAuth.getInstance();

        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.setStatusBarColor(ContextCompat.getColor(this,R.color.secondaryColor));

        final TextInputEditText emailTextField = findViewById(R.id.loginFromEmail);
        final TextInputEditText passwordTextField = findViewById(R.id.loginFromPassword);


        final Button loginButton = findViewById(R.id.loginWithEmail_LoginButton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
                imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                pleaseWaitDialog = new PleaseWaitDialog();
                loginButton.setEnabled(false);
                pleaseWaitDialog.show(getSupportFragmentManager(),"Dialog");
                final String takenEmail = emailTextField.getText().toString().trim();
                final String takenPassword = passwordTextField.getText().toString().trim();
                if(takenEmail.isEmpty()){
                    emailTextField.setError("Empty");
                    emailTextField.requestFocus();
                }
                else if(!EmailValidator.validateEmail(takenEmail)){
                    emailTextField.setError("Enter valid Email Address");
                    emailTextField.requestFocus();
                }
                else if(takenPassword.isEmpty()){
                    Toast.makeText(getApplicationContext(),"Empty",Toast.LENGTH_LONG).show();
                    passwordTextField.requestFocus();
                }
                else if(passwordTextField.length()<=6){
                    Toast.makeText(getApplicationContext(),"Password length should me more than 6 letters.",Toast.LENGTH_LONG).show();
                    passwordTextField.requestFocus();
                }
                else{
                    mAuth.createUserWithEmailAndPassword(takenEmail,takenPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(task.isSuccessful()){
                                pleaseWaitDialog.dismiss();
                                Intent intent = new Intent(LoginWithEmailActivity.this,LoggedInActivity.class);
                                startActivity(intent);
                                finish();
                            }
                            else{
                                if(task.getException() instanceof FirebaseAuthUserCollisionException){
                                    mAuth.signInWithEmailAndPassword(takenEmail,takenPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                        @Override
                                        public void onComplete(@NonNull Task<AuthResult> task) {
                                            if(task.isSuccessful()){

                                                Intent intent = new Intent(LoginWithEmailActivity.this,MainActivity.class);
                                                startActivity(intent);
                                                finish();
                                            }
                                            else{
                                                Toast.makeText(getApplicationContext(),"There was a slight problem while registering the user.",Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                                }
                                pleaseWaitDialog.dismiss();
                            }
                        }
                    });
                }
            }
        });

    }
}
