package com.example.final_sathi;

import android.net.Uri;

import java.util.LinkedList;

public class SathiUser {

    private String userId;
    private String name;
    private String gender;
    private int age;
    private String bio;
    private String distance;
    private String email;
    private String preference;
    private String showAge;
    private LinkedList<Uri> userImages;

    public SathiUser(String id, String n, String g, int a, String b, String d, String e, String p, String showA){

        this.userId = id;
        this.name = n;
        this.gender = g;
        this.age = a;
        this.bio = b;
        this.distance = d;
        this.email = e;
        this.preference = p;
        this.showAge = showA;

    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getShowAge() {
        return showAge;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPreference() {
        return preference;
    }

    public void setPreference(String preference) {
        this.preference = preference;
    }

    public void setShowAge(String showAge) {
        this.showAge = showAge;
    }

    public LinkedList<Uri> getUserImages() {
        return userImages;
    }

    public void setUserImages(LinkedList<Uri> userImages) {
        this.userImages = userImages;
    }
}
