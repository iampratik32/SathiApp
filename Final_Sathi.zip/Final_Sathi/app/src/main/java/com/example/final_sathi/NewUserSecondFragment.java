package com.example.final_sathi;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class NewUserSecondFragment extends Fragment {
    FirebaseAuth firebaseAuth;

    String chosenGender ="";
    String chosenPreference = "";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_new_user_second,container,false);

        Spinner genderSpinner = view.findViewById(R.id.genderSpinner);
        ArrayAdapter<CharSequence> genderAdapter = ArrayAdapter.createFromResource(getContext(),R.array.list_of_gender,R.layout.spinner_center_layout);
        genderAdapter.setDropDownViewResource(R.layout.spinner_center_layout);
        genderSpinner.setAdapter(genderAdapter);
        genderSpinner.setOnItemSelectedListener(new GenderSpinnerClass());


        Spinner preferenceSpinner = view.findViewById(R.id.preferenceSpinner);
        ArrayAdapter<CharSequence> preferenceAdapter = ArrayAdapter.createFromResource(getContext(),R.array.list_of_preference,R.layout.spinner_center_layout);
        preferenceAdapter.setDropDownViewResource(R.layout.spinner_center_layout);
        preferenceSpinner.setAdapter(preferenceAdapter);
        preferenceSpinner.setOnItemSelectedListener(new PreferenceSpinnerClass());

        SeekBar locationBar = view.findViewById(R.id.locationSeekBar);
        final TextView locationDistance = view.findViewById(R.id.newUser_distanceLocation);
        locationBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            int distance = 0;
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                distance = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                locationDistance.setText(distance+" km");
            }
        });

        final TextInputEditText nameOfUser = view.findViewById(R.id.newUserName_text);
        final TextInputEditText emailOfUser = view.findViewById(R.id.newUserEmail_text);
        final TextInputEditText passwordOfUser = view.findViewById(R.id.newUserPassword_text);
        final TextInputEditText ageOfUser = view.findViewById(R.id.newUserAge_text);
        final TextInputEditText bioOfUser = view.findViewById(R.id.newUserBio_text);
        final CheckBox showAge = view.findViewById(R.id.newUser_showAgeCheckButton);

        final Button finishButton = view.findViewById(R.id.newUserFinishButton);
        finishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String takenName = nameOfUser.getText().toString().trim();
                String takenEmail = emailOfUser.getText().toString().trim();
                String takenPassword = passwordOfUser.getText().toString().trim();
                String takenLocation = locationDistance.getText().toString().trim();
                String takenAge = ageOfUser.getText().toString().trim();
                String takenBio = bioOfUser.getText().toString().trim();
                boolean ageChecked = showAge.isChecked();

                if(takenName.isEmpty()){
                    nameOfUser.requestFocus();
                    nameOfUser.setError("Enter Your Name");
                }
                else if(takenEmail.isEmpty()){
                    emailOfUser.requestFocus();
                    emailOfUser.setError("Enter Your Email");
                }
                else if(takenName.matches(".*\\d.*")){
                    nameOfUser.requestFocus();
                    nameOfUser.setError("Enter a valid Name");
                }
                else if(!EmailValidator.validateEmail(takenEmail)){
                    emailOfUser.requestFocus();
                    emailOfUser.setError("Enter a valid Email");
                }
                else if(takenAge.isEmpty()){
                    ageOfUser.requestFocus();
                    ageOfUser.setError("Enter Your Age");
                }
                else if(!takenAge.matches(".*\\d.*")){
                    ageOfUser.requestFocus();
                    ageOfUser.setError("Enter valid Age. ");
                }
                else if(Integer.parseInt(takenAge)<17){
                    Toast.makeText(getContext(),"You must be 18 inorder to continue",Toast.LENGTH_LONG).show();
                }
                else if(takenBio.isEmpty()){
                    bioOfUser.requestFocus();
                    bioOfUser.setError("Bio is Empty.");
                }
                else if(takenBio.length()<25){
                    bioOfUser.requestFocus();
                    bioOfUser.setError("Bio is too short");
                }
                else if(takenPassword.isEmpty()){
                    passwordOfUser.requestFocus();
                    Toast.makeText(getContext(),"Enter your Password",Toast.LENGTH_SHORT).show();
                }
                else if(takenPassword.length()<=6){
                    Toast.makeText(getContext(),"Password length should me more than 6 letters.",Toast.LENGTH_LONG).show();
                }
                else{
                    firebaseAuth = FirebaseAuth.getInstance();
                    FirebaseUser user = firebaseAuth.getCurrentUser();
                    String userId = user.getUid();
                    DatabaseReference currentUserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(chosenGender).child(userId);
                    Map newUser = new HashMap();
                    newUser.put("Preference",chosenPreference);
                    newUser.put("Name",takenName);
                    newUser.put("Email",takenEmail);
                    newUser.put("Distance",takenLocation);
                    newUser.put("Age",takenAge);
                    newUser.put("ShowAge",ageChecked);
                    newUser.put("Bio",takenBio);
                    currentUserDatabase.setValue(newUser);
                    Toast.makeText(getContext(),"User is registered successfully.",Toast.LENGTH_LONG).show();
                    Intent newIntent = new Intent(getActivity(),MainActivity.class);
                    startActivity(newIntent);
                    getActivity().finish();
                }
            }
        });

        return view;
    }

    class GenderSpinnerClass implements AdapterView.OnItemSelectedListener{
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            chosenGender = parent.getItemAtPosition(position).toString();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }

    class PreferenceSpinnerClass implements AdapterView.OnItemSelectedListener{
        @Override
        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
            chosenPreference = parent.getItemAtPosition(position).toString();
        }

        @Override
        public void onNothingSelected(AdapterView<?> parent) {

        }
    }



}
